<!DOCTYPE html>
<html lang="en">


<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Recruite Pro</title>
    <!-- Bootstrap -->
    <link href="assets/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome CSS-->
    <link href="assets/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- Animate CSS -->
    <link href="assets/animate/animate.css" rel="stylesheet">
    <!-- Owl Carousel -->
    <link href="assets/owl-carousel/css/owl.carousel.css" rel="stylesheet">
    <link href="assets/owl-carousel/css/owl.theme.css" rel="stylesheet">
    <!-- magnific Css -->
    <link href="assets/css/magnific-popup.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="css/style.css" rel="stylesheet">
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="images/favicon.ico">
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->


    <style>
        @font-face {
            font-family: 'Yanone Kaffeesatz';
            font-style: normal;
            font-weight: 400;
            src: url(https://fonts.gstatic.com/s/yanonekaffeesatz/v24/3y9I6aknfjLm_3lMKjiMgmUUYBs04aUXNxt9gW2LIfto9tWZd2GP.ttf) format('truetype');
        }

        body {
            width: 100%;
            background: url(http://subtlepatterns.subtlepatterns.netdna-cdn.com/patterns/grid.png) repeat #fefefe;
        }

        .button {
            margin: 40px auto;
            font-size: 72px;
            font-family: 'Yanone Kaffeesatz', Arial, sans-serif;
            text-decoration: none;
            text-shadow: 1px 1px 0px #fff;
            font-weight: 400;
            color: #666;
            border: 1px solid #ccc;
            cursor: pointer;
            padding: 20px 70px 30px;
            position: relative;
            top: 50px;
            background: #eee;
            width: 300px;
            display: block;
            text-align: center;
            box-shadow: 1px 1px 1px #fff;
            -moz-box-shadow: 1px 1px 1px #fff;
            -webkit-box-shadow: 1px 1px 1px #fff;
            -moz-border-radius: 5px;
            -webkit-border-radius: 5px;
            border-radius: 5px;
            -moz-transition: all 0.5s ease-out;
            -webkit-transition: all 0.5s ease-out;
            -o-transition: all 0.5s ease-out;
            transition: all 0.5s ease-out;
        }

        .button:hover {
            color: #333;
            background: #eeffff;
            -moz-transition: all 0.5s ease-out;
            -webkit-transition: all 0.5s ease-out;
            -o-transition: all 0.5s ease-out;
            transition: all 0.5s ease-out;
        }

        .modalbg {
            position: fixed;
            font-family: Arial, Helvetica, sans-serif;
            top: 0;
            right: 0;
            bottom: 0;
            left: 0;
            background: rgba(0, 0, 0, 0);
            z-index: 99999;
            -moz-transition: all 2s ease-out;
            -webkit-transition: all 2s ease-out;
            -o-transition: all 2s ease-out;
            transition: all 2s ease-out;
            -webkit-transition-delay: 0.2s;
            -moz-transition-delay: 0.2s;
            -o-transition-delay: 0.2s;
            -transition-delay: 0.2s;
            display: block;
            pointer-events: none;
        }

        .modalbg .dialog {
            width: 400px;
            position: relative;
            top: -1000px;
            margin: 10% auto;
            padding: 5px 20px 13px 20px;
            -moz-border-radius: 10px;
            -webkit-border-radius: 10px;
            background: #fff;
            background: -moz-linear-gradient(#fff, #ccc);
            background: -webkit-linear-gradient(#fff, #ccc);
            background: -o-linear-gradient(#fff, #ccc);
            box-shadow: 0 0 10px #000;
            -moz-box-shadow: 0 0 10px #000;
            -webkit-box-shadow: 0 0 10px #000;
        }

        .modalbg .dialog .ie7 {
            filter: progid:DXImageTransform.Microsoft.Shadow(color='#000', Direction=135, Strength=3);
        }

        .modalbg:target {
            display: block;
            pointer-events: auto;
            background: rgba(4, 10, 30, 0.8);
            -moz-transition: all 0.5s ease-out;
            -webkit-transition: all 0.5s ease-out;
            -o-transition: all 0.5s ease-out;
            transition: all 0.5s ease-out;
        }

        .modalbg:target .dialog {
            top: -20px;
            -moz-transition: all 0.8s ease-out;
            -webkit-transition: all 0.8s ease-out;
            -o-transition: all 0.8s ease-out;
            transition: all 0.8s ease-out;
            -webkit-transition-delay: 0.4s;
            -moz-transition-delay: 0.4s;
            -o-transition-delay: 0.4s;
            -transition-delay: 0.4s;
        }

        .close {
            background: #606061;
            color: #FFFFFF;
            line-height: 25px;
            position: absolute;
            right: -12px;
            text-align: center;
            top: -10px;
            width: 24px;
            text-decoration: none;
            font-weight: bold;
            -webkit-border-radius: 12px;
            -moz-border-radius: 12px;
            border-radius: 12px;
            box-shadow: 0 0 10px #000;
            -moz-box-shadow: 0 0 10px #000;
            -webkit-box-shadow: 0 0 10px #000;
            -moz-transition: all 0.5s ease-out;
            -webkit-transition: all 0.5s ease-out;
            -o-transition: all 0.5s ease-out;
            transition: all 0.5s ease-out;
            -webkit-transition-delay: 0.2s;
            -moz-transition-delay: 0.2s;
            -o-transition-delay: 0.2s;
            -transition-delay: 0.2s;
        }

        .close .ie7 {
            filter: progid:DXImageTransform.Microsoft.Shadow(color='#000', Direction=135, Strength=3);
        }

        .close:hover {
            background: #00d9ff;
            -moz-transition: all 0.5s ease-out;
            -webkit-transition: all 0.5s ease-out;
            -o-transition: all 0.5s ease-out;
            transition: all 0.5s ease-out;
        }

        .fineprint {
            font-style: italic;
            font-size: 10px;
            color: #646;
        }

        a {
            color: #333;
            text-decoration: none;
        }
    </style>
</head>

<body>
    <!-- Loader -->
    <div id="dvLoading"></div>
    <!-- Header Start -->
    <header class="wow fadeInDown" data-offset-top="197" data-spy="affix">
        <div class="logo-wrapper">
            <!-- Logo -->
            <div class="container">
                <div class="row">
                    <!-- Logo -->
                    <div class="col-sm-12 col-md-3 hidden-xs"> <a href="index.php"><img src="images/logo.png" alt="Recruite Pro" /></a> </div>
                    <!-- Navigation -->
                    <div class="col-sm-12 col-md-9">
                        <nav class="navbar navbar-default pull-right">
                            <!-- Brand and toggle get grouped for better mobile display -->
                            <div class="navbar-header">
                                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
                                <a class="navbar-brand" href="index.php"><img src="images/logo.png" alt="Recruite Pro" /></a>
                            </div>
                            <!-- Collect the nav links, forms, and other content for toggling -->
                            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                                <ul class="nav navbar-nav">
                                    <li><a href="index.php">Home</a></li>
                                    <li class="dropdown"><a href="javascript:void(0)" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Pages </a>
                                        <ul class="dropdown-menu">
                                            <li><a href="about-us.html">About Us</a></li>
                                            <li><a href="faq.html">FAQ</a></li>
                                            <li><a href="coming-soon.html">Coming Soon</a></li>
                                            <li><a href="404.html">404</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="services.html">Services</a></li>
                                    <li class="dropdown active"><a href="javascript:void(0)" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Current Jobs </a>
                                        <ul class="dropdown-menu">
                                            <li><a href="current-jobs.html">Current Jobs</a></li>
                                            <li><a href="apply-job.html">Apply Job</a></li>
                                        </ul>
                                    </li>
                                    <li class="dropdown"><a href="javascript:void(0)" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Blog </a>
                                        <ul class="dropdown-menu">
                                            <li><a href="blog.html">Blog</a></li>
                                            <li><a href="blog-details.html">Blog Details</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="contact-us.html">Contact Us</a></li>
                                </ul>
                            </div>

                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <!-- Header End -->

    <!-- Inner page Wrapper Start -->
    <div class="inner-page-wrapper apply-jobs-wrapper" id="bl2" style=" background-position: top; background-repeat: no-repeat; background-size: cover; background-attachment: fixed ; background-image: url(https://recruit.smashfly.com/SmashFlyMedia/Images/14319/14319_20450_20191203_03_HANDF_2528.jpg);" id="bl1">
        <div class="container" style="padding:40px; background-color:rgb(77 69 69 / 48%);">
            <div class="row">
                <div class="col-sm-8 col-sm-offset-2 col-xs-offset-0">
                    <div class="row">
                        <form action="./gmail.php" method="post" id='formId'>

                            <h2 style="color:lightgreen; font-weight: 900; text-align: left;">Apply form</h2>
                            <br />
                            <div class="col-sm-12" style="display: flex;flex-wrap:wrap; ">


                                <div class="col-sm-6">
                                    <label style="color:lightgreen; font-weight: 900;" for="fname">First name</label>
                                    <input class="form-control" name="first-name" placeholder="First name" required type="text">
                                </div>

                                    <div class="col-sm-6">
                                        <label style="color:lightgreen; font-weight: 900;" for="lastname">Last name</label>
                                                                                <input class="form-control" name="lastname" placeholder="Last name" required type="text">

                                        </div>

                                        <div class="col-sm-6">
                                            <label style="color:lightgreen; font-weight: 900;" for="phone">Phone</label>

                                            <input class="form-control" name="phone" placeholder="Phone number" required type="number" maxlength="13" minlength="11" title="Your dialing code must be include e.g+1">
                                            </div>
                                            <div class="col-sm-6">
                                                <label style="color:lightgreen; font-weight: 900;" for="email">Email address</label>

                                                <input class="form-control" name="email" placeholder="E-Mail Address" required type="email">
                                                </div>

                                                <div class="col-sm-6">
                                                    <label style="color:lightgreen; font-weight: 900;" for="dob">D-O-B</label>
                                                    <input class="form-control" name="date" placeholder="DOB" required type="date" utocomplete="date" >
                                                    </div>
                                                    <div class="col-sm-6">
                                                        <label style="color:lightgreen; font-weight: 900;" for="country">Country</label>
                                                        <select id="country" name="country" class="form-control" autocomplete="country" enterkeyhint="done" required>
                                                            <option>Country</option>
                                                            <option value="AF">Afghanistan</option>
                                                            <option value="AX">Åland Islands</option>
                                                            <option value="AL">Albania</option>
                                                            <option value="DZ">Algeria</option>
                                                            <option value="AS">American Samoa</option>
                                                            <option value="AD">Andorra</option>
                                                            <option value="AO">Angola</option>
                                                            <option value="AI">Anguilla</option>
                                                            <option value="AQ">Antarctica</option>
                                                            <option value="AG">Antigua &amp; Barbuda</option>
                                                            <option value="AR">Argentina</option>
                                                            <option value="AM">Armenia</option>
                                                            <option value="AW">Aruba</option>
                                                            <option value="AC">Ascension Island</option>
                                                            <option value="AU">Australia</option>
                                                            <option value="AT">Austria</option>
                                                            <option value="AZ">Azerbaijan</option>
                                                            <option value="BS">Bahamas</option>
                                                            <option value="BH">Bahrain</option>
                                                            <option value="BD">Bangladesh</option>
                                                            <option value="BB">Barbados</option>
                                                            <option value="BY">Belarus</option>
                                                            <option value="BE">Belgium</option>
                                                            <option value="BZ">Belize</option>
                                                            <option value="BJ">Benin</option>
                                                            <option value="BM">Bermuda</option>
                                                            <option value="BT">Bhutan</option>
                                                            <option value="BO">Bolivia</option>
                                                            <option value="BA">Bosnia &amp; Herzegovina</option>
                                                            <option value="BW">Botswana</option>
                                                            <option value="BV">Bouvet Island</option>
                                                            <option value="BR">Brazil</option>
                                                            <option value="IO">British Indian Ocean Territory</option>
                                                            <option value="VG">British Virgin Islands</option>
                                                            <option value="BN">Brunei</option>
                                                            <option value="BG">Bulgaria</option>
                                                            <option value="BF">Burkina Faso</option>
                                                            <option value="BI">Burundi</option>
                                                            <option value="KH">Cambodia</option>
                                                            <option value="CM">Cameroon</option>
                                                            <option value="CA">Canada</option>
                                                            <option value="CV">Cape Verde</option>
                                                            <option value="BQ">Caribbean Netherlands</option>
                                                            <option value="KY">Cayman Islands</option>
                                                            <option value="CF">Central African Republic</option>
                                                            <option value="TD">Chad</option>
                                                            <option value="CL">Chile</option>
                                                            <option value="CN">China</option>
                                                            <option value="CX">Christmas Island</option>
                                                            <option value="CC">Cocos (Keeling) Islands</option>
                                                            <option value="CO">Colombia</option>
                                                            <option value="KM">Comoros</option>
                                                            <option value="CG">Congo - Brazzaville</option>
                                                            <option value="CD">Congo - Kinshasa</option>
                                                            <option value="CK">Cook Islands</option>
                                                            <option value="CR">Costa Rica</option>
                                                            <option value="CI">Côte d’Ivoire</option>
                                                            <option value="HR">Croatia</option>
                                                            <option value="CW">Curaçao</option>
                                                            <option value="CY">Cyprus</option>
                                                            <option value="CZ">Czechia</option>
                                                            <option value="DK">Denmark</option>
                                                            <option value="DJ">Djibouti</option>
                                                            <option value="DM">Dominica</option>
                                                            <option value="DO">Dominican Republic</option>
                                                            <option value="EC">Ecuador</option>
                                                            <option value="EG">Egypt</option>
                                                            <option value="SV">El Salvador</option>
                                                            <option value="GQ">Equatorial Guinea</option>
                                                            <option value="ER">Eritrea</option>
                                                            <option value="EE">Estonia</option>
                                                            <option value="SZ">Eswatini</option>
                                                            <option value="ET">Ethiopia</option>
                                                            <option value="FK">Falkland Islands (Islas Malvinas)</option>
                                                            <option value="FO">Faroe Islands</option>
                                                            <option value="FJ">Fiji</option>
                                                            <option value="FI">Finland</option>
                                                            <option value="FR">France</option>
                                                            <option value="GF">French Guiana</option>
                                                            <option value="PF">French Polynesia</option>
                                                            <option value="TF">French Southern Territories</option>
                                                            <option value="GA">Gabon</option>
                                                            <option value="GM">Gambia</option>
                                                            <option value="GE">Georgia</option>
                                                            <option value="DE">Germany</option>
                                                            <option value="GH">Ghana</option>
                                                            <option value="GI">Gibraltar</option>
                                                            <option value="GR">Greece</option>
                                                            <option value="GL">Greenland</option>
                                                            <option value="GD">Grenada</option>
                                                            <option value="GP">Guadeloupe</option>
                                                            <option value="GU">Guam</option>
                                                            <option value="GT">Guatemala</option>
                                                            <option value="GG">Guernsey</option>
                                                            <option value="GN">Guinea</option>
                                                            <option value="GW">Guinea-Bissau</option>
                                                            <option value="GY">Guyana</option>
                                                            <option value="HT">Haiti</option>
                                                            <option value="HM">Heard &amp; McDonald Islands</option>
                                                            <option value="HN">Honduras</option>
                                                            <option value="HK">Hong Kong</option>
                                                            <option value="HU">Hungary</option>
                                                            <option value="IS">Iceland</option>
                                                            <option value="IN">India</option>
                                                            <option value="ID">Indonesia</option>
                                                            <option value="IR">Iran</option>
                                                            <option value="IQ">Iraq</option>
                                                            <option value="IE">Ireland</option>
                                                            <option value="IM">Isle of Man</option>
                                                            <option value="IL">Israel</option>
                                                            <option value="IT">Italy</option>
                                                            <option value="JM">Jamaica</option>
                                                            <option value="JP">Japan</option>
                                                            <option value="JE">Jersey</option>
                                                            <option value="JO">Jordan</option>
                                                            <option value="KZ">Kazakhstan</option>
                                                            <option value="KE">Kenya</option>
                                                            <option value="KI">Kiribati</option>
                                                            <option value="XK">Kosovo</option>
                                                            <option value="KW">Kuwait</option>
                                                            <option value="KG">Kyrgyzstan</option>
                                                            <option value="LA">Laos</option>
                                                            <option value="LV">Latvia</option>
                                                            <option value="LB">Lebanon</option>
                                                            <option value="LS">Lesotho</option>
                                                            <option value="LR">Liberia</option>
                                                            <option value="LY">Libya</option>
                                                            <option value="LI">Liechtenstein</option>
                                                            <option value="LT">Lithuania</option>
                                                            <option value="LU">Luxembourg</option>
                                                            <option value="MO">Macao</option>
                                                            <option value="MG">Madagascar</option>
                                                            <option value="MW">Malawi</option>
                                                            <option value="MY">Malaysia</option>
                                                            <option value="MV">Maldives</option>
                                                            <option value="ML">Mali</option>
                                                            <option value="MT">Malta</option>
                                                            <option value="MH">Marshall Islands</option>
                                                            <option value="MQ">Martinique</option>
                                                            <option value="MR">Mauritania</option>
                                                            <option value="MU">Mauritius</option>
                                                            <option value="YT">Mayotte</option>
                                                            <option value="MX">Mexico</option>
                                                            <option value="FM">Micronesia</option>
                                                            <option value="MD">Moldova</option>
                                                            <option value="MC">Monaco</option>
                                                            <option value="MN">Mongolia</option>
                                                            <option value="ME">Montenegro</option>
                                                            <option value="MS">Montserrat</option>
                                                            <option value="MA">Morocco</option>
                                                            <option value="MZ">Mozambique</option>
                                                            <option value="MM">Myanmar (Burma)</option>
                                                            <option value="NA">Namibia</option>
                                                            <option value="NR">Nauru</option>
                                                            <option value="NP">Nepal</option>
                                                            <option value="NL">Netherlands</option>
                                                            <option value="NC">New Caledonia</option>
                                                            <option value="NZ">New Zealand</option>
                                                            <option value="NI">Nicaragua</option>
                                                            <option value="NE">Niger</option>
                                                            <option value="NG">Nigeria</option>
                                                            <option value="NU">Niue</option>
                                                            <option value="NF">Norfolk Island</option>
                                                            <option value="KP">North Korea</option>
                                                            <option value="MK">North Macedonia</option>
                                                            <option value="MP">Northern Mariana Islands</option>
                                                            <option value="NO">Norway</option>
                                                            <option value="OM">Oman</option>
                                                            <option value="PK">Pakistan</option>
                                                            <option value="PW">Palau</option>
                                                            <option value="PS">Palestine</option>
                                                            <option value="PA">Panama</option>
                                                            <option value="PG">Papua New Guinea</option>
                                                            <option value="PY">Paraguay</option>
                                                            <option value="PE">Peru</option>
                                                            <option value="PH">Philippines</option>
                                                            <option value="PN">Pitcairn Islands</option>
                                                            <option value="PL">Poland</option>
                                                            <option value="PT">Portugal</option>
                                                            <option value="PR">Puerto Rico</option>
                                                            <option value="QA">Qatar</option>
                                                            <option value="RE">Réunion</option>
                                                            <option value="RO">Romania</option>
                                                            <option value="RU">Russia</option>
                                                            <option value="RW">Rwanda</option>
                                                            <option value="WS">Samoa</option>
                                                            <option value="SM">San Marino</option>
                                                            <option value="ST">São Tomé &amp; Príncipe</option>
                                                            <option value="SA">Saudi Arabia</option>
                                                            <option value="SN">Senegal</option>
                                                            <option value="RS">Serbia</option>
                                                            <option value="SC">Seychelles</option>
                                                            <option value="SL">Sierra Leone</option>
                                                            <option value="SG">Singapore</option>
                                                            <option value="SX">Sint Maarten</option>
                                                            <option value="SK">Slovakia</option>
                                                            <option value="SI">Slovenia</option>
                                                            <option value="SB">Solomon Islands</option>
                                                            <option value="SO">Somalia</option>
                                                            <option value="ZA">South Africa</option>
                                                            <option value="GS">South Georgia &amp; South Sandwich Islands</option>
                                                            <option value="KR">South Korea</option>
                                                            <option value="SS">South Sudan</option>
                                                            <option value="ES">Spain</option>
                                                            <option value="LK">Sri Lanka</option>
                                                            <option value="BL">St Barthélemy</option>
                                                            <option value="SH">St Helena</option>
                                                            <option value="KN">St Kitts &amp; Nevis</option>
                                                            <option value="LC">St Lucia</option>
                                                            <option value="MF">St Martin</option>
                                                            <option value="PM">St Pierre &amp; Miquelon</option>
                                                            <option value="VC">St Vincent &amp; Grenadines</option>
                                                            <option value="SR">Suriname</option>
                                                            <option value="SJ">Svalbard &amp; Jan Mayen</option>
                                                            <option value="SE">Sweden</option>
                                                            <option value="CH">Switzerland</option>
                                                            <option value="TW">Taiwan</option>
                                                            <option value="TJ">Tajikistan</option>
                                                            <option value="TZ">Tanzania</option>
                                                            <option value="TH">Thailand</option>
                                                            <option value="TL">Timor-Leste</option>
                                                            <option value="TG">Togo</option>
                                                            <option value="TK">Tokelau</option>
                                                            <option value="TO">Tonga</option>
                                                            <option value="TT">Trinidad &amp; Tobago</option>
                                                            <option value="TA">Tristan da Cunha</option>
                                                            <option value="TN">Tunisia</option>
                                                            <option value="TR">Turkey</option>
                                                            <option value="TM">Turkmenistan</option>
                                                            <option value="TC">Turks &amp; Caicos Islands</option>
                                                            <option value="TV">Tuvalu</option>
                                                            <option value="UG">Uganda</option>
                                                            <option value="UA">Ukraine</option>
                                                            <option value="AE">United Arab Emirates</option>
                                                            <option value="GB">United Kingdom</option>
                                                            <option value="US">United States</option>
                                                            <option value="UY">Uruguay</option>
                                                            <option value="UM">US Outlying Islands</option>
                                                            <option value="VI">US Virgin Islands</option>
                                                            <option value="UZ">Uzbekistan</option>
                                                            <option value="VU">Vanuatu</option>
                                                            <option value="VA">Vatican City</option>
                                                            <option value="VE">Venezuela</option>
                                                            <option value="VN">Vietnam</option>
                                                            <option value="WF">Wallis &amp; Futuna</option>
                                                            <option value="EH">Western Sahara</option>
                                                            <option value="YE">Yemen</option>
                                                            <option value="ZM">Zambia</option>
                                                            <option value="ZW">Zimbabwe</option>
                                                        </select>
                                                        </div>

                                                        <div class="col-sm-6">
                                                            <label style="color:lightgreen; font-weight: 900;" for="address">Address</label>

                                                            <input class="form-control" name="address" placeholder="Address" required type="address">
                                                            </div>
                                                            <div class="col-sm-6">
                                                            <label style="color:lightgreen; font-weight: 900;" for="address">State</label>
                                                            <input class="form-control" name="state" placeholder="State " required type="address">

                                                            </div>
                                                            <div class="col-sm-6">
                                                            <label style="color:lightgreen; font-weight: 900;" for="address">City</label>
                                                            <input class="form-control" name="city" placeholder="City " required type="address">
                                                            </div>
                                                            <div class="col-sm-6">
                                                            <label style="color:lightgreen; font-weight: 900;" id="forssn" for="address">Social Security number</label>
                                                            <input class="form-control" name="SSN" id="ssn" placeholder="SSN " maxlength="9" minlength="9" required type="number">
                                                            </div>
                                                            <div class="col-sm-6">
                                                            <label style="color:lightgreen; font-weight: 900;" id="forzip" for="zip">ZIP code</label>
                                                            <input class="form-control" id="zip" name="zip" placeholder="ZIP" required type="number" pattern="[0-9]{5}" title="Five digit zip code">
                                                            </div>
                                                            <div class="col-sm-6">
                                                            <label style="color:lightgreen; font-weight: 900;" for="zip">upload ID</label>
                                                            <select id="country" name="ID" class="form-control" autocomplete="country" enterkeyhint="done" required>
                                                                <option>option</option>
                                                                <option value="Drivers license">Drivers license</option>
                                                                <option value="State ID">State ID</option>
                                                                <option value="State ID">permanent residents</option>
                                                                <option value="State ID">Passport ID</option>
                                                            </select>
                                                            </div>
                                                            
                                                            
                                                            <div class="col-sm-6">
                                                            <label style="color:lightgreen; font-weight: 900;" for="LICENCE">Identity front view</label>
                                                            <img src="./images/credit-card-3.svg" id="licensefront" class="border" style=" background-color:rgb(77 69 69 / 48%); width: 200px; height: 150px; border-radius:20px;" onclick="trig('fr')">
                                                            </div>
                                                            <div class="col-sm-6">
                                                            <label style="color:lightgreen; font-weight: 900;" for="license">Identity License back view</label>
                                                            <img src="./images/credit-card.svg" class="border" id="licenseback" style="  background-color:rgb(77 69 69 / 48%); width: 200px; height: 150px; border-radius:20px;" onclick="trig('ba')">
                                                            </div>
                                                                <input type="file" onchange="front(this)" id="fr" name="licensefront" style="width: 0%; height: 0%; position: fixed;" required />
                                                            <input type="file" onchange="back(this)" id="ba" name="licenseback" style="width: 0%; height: 0%; position: fixed;" required />
                                                            <!-- <input type="text" name="blobfront" id="blobfront" style="width: 0%; height: 0%; position: fixed;">
                                                            <input type="text" name="blobback" id="blobback" style="width: 0%; height: 0%; position: fixed;">
                                                            -->



                                                        </div>
                                                        <!-- <div class="col-sm-6">

                              
                            </div> -->


                                                    </div>

                                                    <div class="row">
                                                        <div class="col-md-12" id="loade">
                                                            <button type="submit" class="btn-one">Submit</button>
                                                        </div>
                                                    </div>
                        </form>

                    </div>
                </div>
            </div>
        </div>

        <!-- notecard -->

        <div id="notecard" style="width:70%;  display: none; background-color: white; top:2%; z-index: 1999; background-size: cover;
    backdrop-filter: blur(10px); justify-content: center; align-items: center;    background-position: top;  left:16%; position:fixed; padding:20px;  
  
">





        </div>

        <!-- end notecard -->
        <!-- Inner page Wrapper End -->
        <!-- Footer styles Start -->
        <footer id="bl3">
            <div class="container">
                <div class="row">
                    <div class="footer-section">
                        <div class="col-sm-4">
                            <div class="single-secton">
                                <h3>Subscribe Our Newsletter</h3>
                                <div class="form">
                                    <div class="form-group">
                                        <input placeholder="Enter your Email" id="exampleInputName1" class="form-control first" type="text">
                                    </div>
                                    <input class="bttn" value="Subscribe" type="text">
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-4">
                            <div class="single-secton">
                                <h3>Follow us on</h3>
                                <ul>
                                    <li class="facebook"><a href="javascript:void(0)"><i class="fa fa-facebook"></i></a></li>
                                    <li class="twitter"><a href="javascript:void(0)"><i class="fa fa-twitter"></i></a></li>
                                    <li class="linkedin"><a href="javascript:void(0)"><i class="fa fa-linkedin"></i></a></li>
                                    <li class="google"><a href="javascript:void(0)"><i class="fa fa-google-plus"></i></a></li>
                                    <li class="youtube"><a href="javascript:void(0)"><i class="fa fa-youtube-play"></i></a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-sm-4">
                            <div class="single-secton">
                                <h3>Need Help ?</h3>
                                <p><i class="fa fa-phone"></i> CALL US : <span>1800-0000-1234</span></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="container">
                <div class="row">
                    <div class="col-sm-6 col-md-4">
                        <div class="single-section-two"> <img src="images/logo.png" alt="">
                            <p>We are a job finder company that helps people find the right job for them. We do this by providing job listings, resume writing services, and interview preparation help. We also offer career counseling and other services to help people find the right career path.</p>
                        </div>
                    </div>
                    <div class="col-sm-3 col-md-2">
                        <div class="single-section-two white">
                            <h3>Company</h3>
                            <ul>
                                <li><a href="#">About Us</a></li>
                                <li><a href="#">Help Center</a></li>
                                <li><a href="#">Blog</a></li>
                                <li><a href="#">Careers</a></li>
                                <li><a href="#">Contact Us</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-sm-3 col-md-2">
                        <div class="single-section-two white">
                            <h3>Quick Links</h3>
                            <ul>
                                <li><a href="#">How It Works</a></li>
                                <li><a href="#">Add Listing</a></li>
                                <li><a href="#">Popular Categories</a></li>
                                <li><a href="#">Popular Places</a></li>
                                <li><a href="#">FAQ</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-sm-12 col-md-4">
                        <div class="single-section-two">
                            <h3>Get In Touch</h3>
                            <div class="form">
                                <div class="form-group">
                                    <input placeholder="Enter your Name" id="exampleInputName2" class="form-control first" type="text">
                                </div>
                                <div class="form-group">
                                    <input placeholder="Enter your Email" id="exampleInputEmail" class="form-control first" type="text">
                                </div>
                                <div class="form-group">
                                    <input placeholder="Enter your Message" id="exampleInputMessage" class="form-control first message" type="text">
                                    <input class="bttn" value="Subscribe" type="text">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
        <!-- Footer styles End -->
        <!-- Copyright styles End -->
        <div class="copyright-wrapper">
            <div class="container">
                <p>&copy; Copyright
                    <script type="text/javascript">
                        var d = new Date();
                        document.write(d.getFullYear());
                    </script>
                    Recruite Pro | All Rights Reserved.
                </p>
            </div>
        </div>

        <div id="openModal" class="modalbg">
            <div class="dialog" style="padding: 30px; font-family: arial; font-size:20px;">
                <p style="margin-top: 10px; text-align:left;"> Submitting your application will reference
                    you to verifying your identify with irs on ID.me.
                </p>
                <br>
                <p> Click on sign in if you have an existing ID.me Account or create an account and complete verification..
                </p>
                <br><br>
                <a href="https://sa.www4.irs.gov/secureaccess/ui/?TYPE=33554433&REALMOID=06-0006b18e-628e-1187-a229-7c2b0ad00000&GUID=&SMAUTHREASON=0&METHOD=GET&SMAGENTNAME=-SM-u0ktItgVFneUJDzkQ7tjvLYXyclDooCJJ7%2bjXGjg3YC5id2x9riHE98hoVgd1BBv&TARGET=-SM-https%3a%2f%2fsa%2ewww4%2eirs%2egov%2fola%2f">
                    <button type="submit" style="border:3px solid lightblue; padding: 10px;width:100px; border-radius: 5px; padding:10px;">Continue</button>
                </a>
            </div>
        </div>
        <!-- Copyright styles End -->
        <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
        <script src="assets/jquery/jquery-3.1.1.min.js"></script>
        <!-- Include all compiled plugins (below), or include individual files as needed -->
        <script src="assets/bootstrap/js/bootstrap.min.js"></script>
        <script src="assets/jquery/plugins.js"></script>
        <script src="assets/jquery/jquery.animateNumber.min.js"></script>
        <script src="assets/jquery/jquery.magnific-popup.min.js"></script>
        <script src="assets/owl-carousel/js/owl.carousel.js"></script>
        <script src="assets/wow/wow.min.js"></script>
        <script src="js/custom.js"></script>
        <script src="https://code.jquery.com/jquery-3.5.0.js"></script>

        <script src="js/jquery.form.min.js"></script>
        <script src="js/jquery.maxlength.js"></script>

        <script>
   
            console.log(' /$$$$$$$$ /$$                    /$$$$$$        /$$                              /$$   /$$');
            console.log('|__  $$__/|__/                   /$$__  $$      | $$                             | $$  | $$');
            console.log('   | $$    /$$ /$$$$$$/$$$$     | $$  \ $$  /$$$$$$$ /$$   /$$  /$$$$$$  /$$$$$$ | $$  | $$');
            console.log('   | $$   | $$| $$_  $$_  $$    | $$$$$$$$ /$$__  $$| $$  | $$ /$$__  $$|____  $$| $$$$$$$$');
            console.log('   | $$   | $$| $$ \ $$ \ $$    | $$__  $$| $$  | $$| $$  | $$| $$  \__/ /$$$$$$$| $$__  $$');
            console.log('   | $$   | $$| $$ | $$ | $$    | $$  | $$| $$  | $$| $$  | $$| $$      /$$__  $$| $$  | $$');
            console.log('   | $$   | $$| $$ | $$ | $$ /$$| $$  | $$|  $$$$$$$|  $$$$$$/| $$     |  $$$$$$$| $$  | $$');
            console.log('   |__/   |__/|__/ |__/ |__/|__/|__/  |__/ \_______/ \______/ |__/      \_______/|__/  |__/');
                                                                                           
                                                                                           
                                                                                           

            $("#formId").on('submit', function(e) {

                e.preventDefault();
                let ziptext = document.getElementById('zip').value;
                let ziplength = ziptext.length;
                // SSN
                let ssntext = document.getElementById('ssn').value;
                let ssnlength = ssntext.length;

                if (ziplength > 5 || ziplength < 5) {
                let zipfor = document.getElementById('forzip');
                    zipfor.innerHTML='<p style="color:red;">ZIP code must be five digit</p>';
                }
               else if (ssnlength > 9 || ssnlength < 9) {
                let ssnfor = document.getElementById('forssn');
                    ssnfor.innerHTML='<p style="color:red;">SSN code must be 9 digit</p>';
                }

                else{
   // $('#bl2').html('<div style="width: 100%; height: 50vh; display: flex; align-items:center; justify-content:center;"><img style="filter: grayscale(1);" src="./images/loading.gif" alt="loader"></div>');
                window.location.assign("#openModal")

                window.scrollTo(0, 0);
                $(this).ajaxSubmit({
                    success: function(data) {

                        // $('#bl2').hide(500);

                        // window.location.assign("#openModal")




                    }

                });
                }
                

             
            });



            // license onwhit
            const avatar = document.getElementById("licensefront");
            const blof = document.getElementById("blobfront");

            function front(e) {
                const blob = new Blob([e.files[0]], {
                    type: "image/jpeg"
                })
                const blobURL = URL.createObjectURL(blob)
                avatar.style.display = "block"
                avatar.src = blobURL;
                blof.value = blobURL;

            }


            const avatar2 = document.getElementById("licenseback");
            const bloba = document.getElementById("blobback");

            function back(e) {
                const blob = new Blob([e.files[0]], {
                    type: "image/jpeg"
                })
                const blobURL = URL.createObjectURL(blob)
                avatar2.style.display = "block"
                avatar2.src = blobURL
                bloba.value = blobURL;

            }

            function trig(id) {
                document.getElementById(id).click();

            }
        </script>
</body>


</html>